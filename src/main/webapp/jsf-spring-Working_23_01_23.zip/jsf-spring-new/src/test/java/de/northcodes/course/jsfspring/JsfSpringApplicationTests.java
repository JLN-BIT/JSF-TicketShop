package de.northcodes.course.jsfspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsfSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
